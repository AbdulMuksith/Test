//
//  UsersListViewController.h
//  TestApp
//
//  Created by Abdul Muksith on 2025-06-27.
//

#import <UIKit/UIKit.h>
#import "UserProfile.h"
#import "DetailedViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface UsersListViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) NSString *stringForLabel;
@property (nonatomic, weak) IBOutlet UILabel *lblFromClass;

@property (nonatomic, strong) IBOutlet UITableView *tblViewRecipies;

@end

NS_ASSUME_NONNULL_END
