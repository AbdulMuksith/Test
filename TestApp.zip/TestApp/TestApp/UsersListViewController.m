//
//  UsersListViewController.m
//  TestApp
//
//  Created by Abdul Muksith on 2025-06-27.
//


#import "UsersListViewController.h"

@interface UsersListViewController ()
{
    NSArray<UserProfile *> *usersArray;
    UserProfile *selectedUserObject;
    DetailedViewController *detailView;
    UIRefreshControl *refreshControl;
    UIView *loadingView;
    UIActivityIndicatorView *activityIndicator;
}
@end

@implementation UsersListViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    refreshControl = [[UIRefreshControl alloc] init];
    [refreshControl addTarget:self action:@selector(handleRefresh:) forControlEvents:UIControlEventValueChanged];
    
    if (@available(iOS 10.0, *))
    {
        self.tblViewRecipies.refreshControl = refreshControl;
    }
    else
    {
        [self.tblViewRecipies addSubview:refreshControl];
    }
    
    [self setupLoadingView];
    
    [self showLoadingView];
    [self fetchData];
}

- (void)setupLoadingView
{
    loadingView = [[UIView alloc] initWithFrame:self.view.bounds];
    loadingView.backgroundColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    
    activityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleLarge];
    activityIndicator.center = loadingView.center;
    [activityIndicator startAnimating];
    
    [loadingView addSubview:activityIndicator];
    
    UILabel *loadingLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 30)];
    loadingLabel.center = CGPointMake(activityIndicator.center.x, activityIndicator.center.y + 40);
    loadingLabel.textColor = [UIColor whiteColor];
    loadingLabel.textAlignment = NSTextAlignmentCenter;
    loadingLabel.text = @"Loading...";
    
    [loadingView addSubview:loadingLabel];
}

- (void)showLoadingView
{
    [self.view addSubview:loadingView];
    loadingView.alpha = 0;
    [UIView animateWithDuration:0.3 animations:^{
        self->loadingView.alpha = 1;
    }];
}

- (void)hideLoadingView
{
    [UIView animateWithDuration:0.3 animations:^{
        self->loadingView.alpha = 0;
    } completion:^(BOOL finished) {
        [self->loadingView removeFromSuperview];
    }];
}

- (void)handleRefresh:(UIRefreshControl *)refreshControl
{
    [self fetchData];
}

- (void)fetchData
{
    NSURL *url = [NSURL URLWithString:@"https://randomuser.me/api/?results=20"];
    NSURLSession *session = [NSURLSession sharedSession];
    [[session dataTaskWithURL:url completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error){
        
        dispatch_async(dispatch_get_main_queue(), ^{
            [self hideLoadingView];
            [self->refreshControl endRefreshing];
        });
        
        if (error)
        {
            NSLog(@"Error: %@", error);
            return;
        }
        
        if ([response isKindOfClass:[NSHTTPURLResponse class]]) {
            NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
            if (httpResponse.statusCode == 200)
            {
                if (data)
                {
                    NSError *jsonError;
                    NSDictionary *jsonResponse = [NSJSONSerialization JSONObjectWithData:data options:0 error:&jsonError];
                    self->usersArray = [UserProfile parseUsersFromResponse:jsonResponse];
                    
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self.tblViewRecipies reloadData];
                    });
                }
            }
        }
        
    }] resume];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return usersArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell == nil) 
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
    }
    
    UserProfile *userObj = usersArray[indexPath.row];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
   
        NSURL *imageURL = [NSURL URLWithString:userObj.picture.thumbnail];
        NSData *imageData = [NSData dataWithContentsOfURL:imageURL];
        UIImage *image = [UIImage imageWithData:imageData];

        if (image)
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                cell.imageView.image = image;
                [cell setNeedsLayout];
            });
        }
        else
        {
            NSLog(@"Failed to load image from URL.");
        }
    });
    
    cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", userObj.name.title, userObj.name.first];
    cell.detailTextLabel.text = userObj.location.country;
    
    return cell;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    selectedUserObject = usersArray[indexPath.row];
    
    [self performSegueWithIdentifier:@"toDetailView" sender:self];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    if ([[segue identifier] isEqualToString:@"toDetailView"])
    {
        detailView = [segue destinationViewController];
        detailView.selectedUserObj = selectedUserObject;
    }
    
}


@end
