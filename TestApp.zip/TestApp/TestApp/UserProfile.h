//
//  UserProfile.h
//  TestApp
//
//  Created by Abdul Muksith on 2025-06-27.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Name : NSObject
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *first;
@property (nonatomic, strong) NSString *last;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
@end

@interface Location : NSObject
@property (nonatomic, strong) NSString *city;
@property (nonatomic, strong) NSString *country;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
@end

@interface DOB : NSObject
@property (nonatomic, strong) NSString *date;
@property (nonatomic, assign) NSInteger age;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
@end

@interface Picture : NSObject
@property (nonatomic, strong) NSString *large;
@property (nonatomic, strong) NSString *medium;
@property (nonatomic, strong) NSString *thumbnail;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
@end

@interface UserProfile : NSObject
@property (nonatomic, strong) NSString *gender;
@property (nonatomic, strong) Name *name;
@property (nonatomic, strong) Location *location;
@property (nonatomic, strong) NSString *email;
@property (nonatomic, strong) DOB *dob;
@property (nonatomic, strong) NSString *phone;
@property (nonatomic, strong) Picture *picture;
@property (nonatomic, strong) NSString *nat;

- (instancetype)initWithDictionary:(NSDictionary *)dict;
+ (NSArray<UserProfile *> *)parseUsersFromResponse:(NSDictionary *)response;
@end

NS_ASSUME_NONNULL_END
