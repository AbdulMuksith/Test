//
//  SceneDelegate.h
//  TestApp
//
//  Created by Abdul Muksith on 2025-03-28.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

