//
//  DetailedViewController.m
//  TestApp
//
//  Created by Abdul Muksith on 2025-06-27.
//

#import "DetailedViewController.h"

@interface DetailedViewController ()

@end

@implementation DetailedViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        NSURL *imageURL = [NSURL URLWithString:self.selectedUserObj.picture.large];
        NSData *imageData = [NSData dataWithContentsOfURL:imageURL];
        UIImage *image = [UIImage imageWithData:imageData];
        
        if (image)
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                self.imgUserImg.image = image;
                [self.imgUserImg setNeedsLayout];
            });
        }
        else
        {
            NSLog(@"Failed to load image from URL.");
        }
    });
    
    NSString *fullname = [NSString stringWithFormat:@"Full Name: %@ %@", self.selectedUserObj.name.first, self.selectedUserObj.name.last];
    NSString *email = [NSString stringWithFormat:@"Email: %@", self.selectedUserObj.email];
    NSString *phone = [NSString stringWithFormat:@"Phone: %@", self.selectedUserObj.phone];
    NSString *country = [NSString stringWithFormat:@"Origin: %@ %@", self.selectedUserObj.location.city, self.selectedUserObj.location.country];
    
    self.txtViewDetails.text = [NSString stringWithFormat:@"%@\n%@\n%@\n%@\n", fullname, email, phone, country];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
