//
//  UserProfile.m
//  TestApp
//
//  Created by Abdul Muksith on 2025-06-27.
//


#import "UserProfile.h"

@implementation Name
- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    if (self) {
        _title = dict[@"title"] ?: @"";
        _first = dict[@"first"] ?: @"";
        _last = dict[@"last"] ?: @"";
    }
    return self;
}
@end

@implementation Location
- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    if (self) {
        _city = dict[@"city"] ?: @"";
        _country = dict[@"country"] ?: @"";
    }
    return self;
}
@end

@implementation DOB
- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    if (self) {
        _date = dict[@"date"] ?: @"";
        _age = [dict[@"age"] integerValue] ?: 0;
    }
    return self;
}
@end

@implementation Picture
- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    if (self) {
        _large = dict[@"large"] ?: @"";
        _medium = dict[@"medium"] ?: @"";
        _thumbnail = dict[@"thumbnail"] ?: @"";
    }
    return self;
}
@end

@implementation UserProfile
- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    if (self) {
        _gender = dict[@"gender"] ?: @"";
        _name = [[Name alloc] initWithDictionary:dict[@"name"]];
        _location = [[Location alloc] initWithDictionary:dict[@"location"]];
        _email = dict[@"email"] ?: @"";
        _dob = [[DOB alloc] initWithDictionary:dict[@"dob"]];
        _phone = dict[@"phone"] ?: @"";
        _picture = [[Picture alloc] initWithDictionary:dict[@"picture"]];
        _nat = dict[@"nat"] ?: @"";
    }
    return self;
}

+ (NSArray<UserProfile *> *)parseUsersFromResponse:(NSDictionary *)response {
    NSMutableArray *users = [NSMutableArray array];
    NSArray *results = response[@"results"];
    
    for (NSDictionary *userDict in results) {
        UserProfile *user = [[UserProfile alloc] initWithDictionary:userDict];
        [users addObject:user];
    }
    
    return [users copy];
}
@end
